/*
* Assignment 1
* InClass01
* Kevin Heu , Samuel Petty
* */
package com.example.kevin.inclass01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView tri = (ImageView) findViewById(R.id.triangle);
        ImageView sqr = (ImageView) findViewById(R.id.square);
        ImageView cir = (ImageView) findViewById(R.id.circle);
        final Button calc = (Button) findViewById(R.id.calc);
        final Button clr = (Button) findViewById(R.id.clear);
        tri.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                    Log.d("demo", "Triangle");
                TextView leng2 = findViewById( R.id.lenght2);
                leng2.setVisibility(View.VISIBLE);
                TextView line2 = findViewById( R.id.editText2);
                line2.setVisibility(View.VISIBLE);
                TextView display = findViewById( R.id.display);
                display.setText("Triangle");
                calc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TextView line = findViewById(R.id.editText);
                        TextView line2 = findViewById(R.id.editText2);
                        double var = Double.parseDouble(line.getText().toString());
                        double var2 = Double.parseDouble(line2.getText().toString());
                        double var3 = 0.5*var*var2;
                        String val = Double.toString(var3);
                        TextView out = findViewById(R.id.editText3);
                        out.setText(val);
                        Log.d("final",val);
                    }
                });
                }
        });
        sqr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d("demo", "Square");
                TextView leng2 = findViewById( R.id.lenght2);
                leng2.setVisibility(View.INVISIBLE);
                TextView line2 = findViewById( R.id.editText2);
                line2.setVisibility(View.INVISIBLE);
                TextView display = findViewById( R.id.display);
                display.setText("Square");
                calc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TextView line = findViewById(R.id.editText);
                        double var = Double.parseDouble(line.getText().toString());
                        var = var*var;
                        String val = Double.toString(var);
                        TextView out = findViewById(R.id.editText3);
                        out.setText(val);
                        Log.d("final",val);
                    }
                });
            }
        });
        cir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d("demo", "Circle");
                TextView leng2 = findViewById( R.id.lenght2);
                leng2.setVisibility(View.INVISIBLE);
                TextView line2 = findViewById( R.id.editText2);
                line2.setVisibility(View.INVISIBLE);
                TextView display = findViewById( R.id.display);
                display.setText("Circle");
                calc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TextView line = findViewById(R.id.editText);
                        double var = Double.parseDouble(line.getText().toString());
                        var = 3.14*var*var;
                        String val = Double.toString(var);
                        TextView out = findViewById(R.id.editText3);
                        out.setText(val);
                        Log.d("final",val);
                    }
                });
            }
        });

  clr.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
          TextView line = findViewById(R.id.editText);
          line.setText("");
          TextView leng2 = findViewById( R.id.lenght2);
          leng2.setVisibility(View.VISIBLE);
          TextView line2 = findViewById( R.id.editText2);
          line2.setVisibility(View.VISIBLE);
          line2.setText("");
          TextView out = findViewById(R.id.editText3);
          out.setText("");
          TextView display = findViewById( R.id.display);
          display.setText("Select a Shape");
      }
  });

    }
}
